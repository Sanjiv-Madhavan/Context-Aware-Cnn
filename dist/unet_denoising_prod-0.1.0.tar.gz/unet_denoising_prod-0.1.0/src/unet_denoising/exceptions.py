class DenoisingError(Exception):
    """Base exception for this project."""
