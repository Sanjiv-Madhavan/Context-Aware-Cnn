from __future__ import annotations

import argparse

from unet_denoising.config import load_config


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="UNet denoising pipeline")
    parser.add_argument("--config", required=True, help="Path to YAML config")

    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("train", help="Run training pipeline")
    sub.add_parser("infer", help="Run inference pipeline")
    return parser


def main() -> None:
    args = build_parser().parse_args()
    cfg = load_config(args.config)

    if args.command == "train":
        from unet_denoising.pipelines.train_pipeline import run_train

        run_train(cfg)
    elif args.command == "infer":
        from unet_denoising.pipelines.infer_pipeline import run_infer

        run_infer(cfg)


if __name__ == "__main__":
    main()
