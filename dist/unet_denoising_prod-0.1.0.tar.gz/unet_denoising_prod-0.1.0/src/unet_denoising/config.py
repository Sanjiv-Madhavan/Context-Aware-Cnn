from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml


@dataclass
class PathsConfig:
    noisy_train_dir: str
    gt_train_dir: str
    noisy_val_dir: str
    gt_val_dir: str
    noisy_infer_dir: str
    gt_infer_dir: str


@dataclass
class StorageConfig:
    google_drive_root: str
    experiment_name: str


@dataclass
class DataConfig:
    patch_size: int
    border_size: int
    crops_per_image: int
    val_ratio: float
    num_workers: int


@dataclass
class TrainConfig:
    seed: int
    epochs: int
    batch_size: int
    lr: float
    checkpoint_every: int


@dataclass
class InferenceConfig:
    checkpoint_name: str


@dataclass
class AppConfig:
    paths: PathsConfig
    storage: StorageConfig
    data: DataConfig
    train: TrainConfig
    inference: InferenceConfig



def load_config(path: str | Path) -> AppConfig:
    cfg_path = Path(path)
    payload: dict[str, Any] = yaml.safe_load(cfg_path.read_text())
    return AppConfig(
        paths=PathsConfig(**payload["paths"]),
        storage=StorageConfig(**payload["storage"]),
        data=DataConfig(**payload["data"]),
        train=TrainConfig(**payload["train"]),
        inference=InferenceConfig(**payload["inference"]),
    )
