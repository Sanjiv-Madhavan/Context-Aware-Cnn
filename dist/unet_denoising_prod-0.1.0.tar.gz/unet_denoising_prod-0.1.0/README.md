# UNet Denoising Production Refactor

This repository refactors `UNetDenoising (6).ipynb` into a production-style, modular codebase.

## Project Layout

```
configs/
  config.yaml
scripts/
  train.py
  infer.py
src/unet_denoising/
  cli.py
  config.py
  logging_utils.py
  exceptions.py
  data/
    io.py
    datasets.py
  models/
    unet.py
  training/
    engine.py
  inference/
    halo.py
  pipelines/
    train_pipeline.py
    infer_pipeline.py
  storage/
    google_drive.py
```

## Key Refactor Decisions

- Notebook logic was split into clear layers: config, data, model, training, inference, pipeline.
- Storage is implemented for **Google Drive mounted directories**, not MongoDB.
- All run outputs are written under:
  - `<google_drive_root>/experiments/<experiment_name>/checkpoints`
  - `<google_drive_root>/experiments/<experiment_name>/runs/train_YYYYMMDD_HHMMSS/*`
  - `<google_drive_root>/experiments/<experiment_name>/runs/infer_YYYYMMDD_HHMMSS/*`

## Install

```bash
pip install -r requirements.txt
pip install -e .
```

## Configure

Edit `configs/config.yaml` for your paths and hyperparameters.

## Run

```bash
python -m unet_denoising.cli --config configs/config.yaml train
python -m unet_denoising.cli --config configs/config.yaml infer
```

Or use shortcuts:

```bash
python scripts/train.py
python scripts/infer.py
```

## Notes

- Training/inference preserves your halo-based patch approach from the notebook.
- Normalization stats are persisted as JSON and reused at inference time.
- Every run writes a dedicated log file (`train.log` / `infer.log`) and `run_summary.json`.
